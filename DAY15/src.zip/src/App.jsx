import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";
import "./App.css";

function App() {
  return (
    <>
      <Navbar />

      <main>
        <h1>Welcome to My React App</h1>
      </main>

      <Footer />
    </>
  );
}

export default App;