import "./Navbar.css";

function Navbar() {
  return (
    <>
      {/* TOP BAR */}
      <div className="topbar">
        🎉 Use code <strong>TAPRI50</strong> for 50% off on your first order!
      </div>

      {/* NAVBAR */}
      <nav className="navbar">

        <div className="logo">
          <div className="logo-icon">🍵</div>
          Tapri<span>Food</span>
        </div>

        <ul className="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#menu">Menu</a></li>
          <li><a href="#offer">Offers</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>

        <a href="#menu">
          <button className="nav-btn">
            Order Now
          </button>
        </a>

      </nav>
    </>
  );
}

export default Navbar;