import "./Footer.css";

function Footer() {
  return (
    <footer>

      <div className="footer-top">

        <div className="footer-col">

          <div className="logo-footer">
            TapriFood
          </div>

          <p>
            Bringing the soul of the street tapri to your doorstep.
            Authentic flavours, honest prices, fast delivery.
          </p>

        </div>

        <div className="footer-col">

          <h4>Quick Links</h4>

          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Menu</a></li>
            <li><a href="#">Offers</a></li>
            <li><a href="#">Contact</a></li>
          </ul>

        </div>

        <div className="footer-col">

          <h4>Categories</h4>

          <ul>
            <li><a href="#">Main Course</a></li>
            <li><a href="#">Chaat & Snacks</a></li>
            <li><a href="#">Beverages</a></li>
            <li><a href="#">Desserts</a></li>
          </ul>

        </div>

        <div className="footer-col">

          <h4>Follow Us</h4>

          <ul>
            <li><a href="#">Instagram</a></li>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">YouTube</a></li>
          </ul>

        </div>

      </div>

      <div className="footer-bottom">

        <p>
          © 2025 TapriFood · taprifood.in · All rights reserved ·
          Made with ❤️ in Ahmedabad
        </p>

      </div>

    </footer>
  );
}

export default Footer;